var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/youtube/status/route.js")
R.c("server/chunks/[root-of-the-server]__475893ef._.js")
R.c("server/chunks/[root-of-the-server]__d9d99d6e._.js")
R.c("server/chunks/[root-of-the-server]__5a7c98b2._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_youtube_status_route_actions_c6457bad.js")
R.m(53290)
module.exports=R.m(53290).exports
