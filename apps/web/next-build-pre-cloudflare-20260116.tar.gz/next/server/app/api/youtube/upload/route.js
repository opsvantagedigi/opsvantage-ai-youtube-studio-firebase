var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/youtube/upload/route.js")
R.c("server/chunks/[root-of-the-server]__c0b70a80._.js")
R.c("server/chunks/[root-of-the-server]__5a7c98b2._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_youtube_upload_route_actions_e90489a8.js")
R.m(59375)
module.exports=R.m(59375).exports
