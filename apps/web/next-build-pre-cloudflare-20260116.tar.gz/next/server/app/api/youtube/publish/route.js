var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/youtube/publish/route.js")
R.c("server/chunks/[root-of-the-server]__7701397e._.js")
R.c("server/chunks/[root-of-the-server]__d9d99d6e._.js")
R.c("server/chunks/[root-of-the-server]__5a7c98b2._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_youtube_publish_route_actions_52b37937.js")
R.m(84502)
module.exports=R.m(84502).exports
