var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__5a7c98b2._.js")
R.c("server/chunks/718d8_next_dist_esm_build_templates_app-route_ef07152f.js")
R.c("server/chunks/apps_web__next-internal_server_app_favicon_ico_route_actions_63c3b0d9.js")
R.m(16925)
module.exports=R.m(16925).exports
