globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/4fc20c89f5f8ac50.js",
    "static/chunks/bf93eb8a0c555955.js",
    "static/chunks/4b91f44b68ab08b9.js",
    "static/chunks/0d56028cf8911ba3.js",
    "static/chunks/turbopack-da676eff3af4a989.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];