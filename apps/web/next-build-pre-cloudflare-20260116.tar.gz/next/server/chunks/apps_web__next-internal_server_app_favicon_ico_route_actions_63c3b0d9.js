module.exports=[45075,(e,o,d)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_favicon_ico_route_actions_63c3b0d9.js.map