module.exports=[3039,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_studio_settings_page_actions_111f3734.js.map