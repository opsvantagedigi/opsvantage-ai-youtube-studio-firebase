module.exports=[20850,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_studio_page_actions_54fbab6b.js.map