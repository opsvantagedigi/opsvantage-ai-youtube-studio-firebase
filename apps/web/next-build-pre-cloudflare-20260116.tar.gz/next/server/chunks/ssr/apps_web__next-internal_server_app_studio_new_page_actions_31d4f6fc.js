module.exports=[97687,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_studio_new_page_actions_31d4f6fc.js.map