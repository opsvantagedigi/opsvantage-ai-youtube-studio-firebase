module.exports=[99671,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_studio_account_page_actions_87c257ce.js.map