module.exports=[71279,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},88959,a=>{"use strict";let b={src:a.i(71279).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=apps_web_app_e92ffe16._.js.map